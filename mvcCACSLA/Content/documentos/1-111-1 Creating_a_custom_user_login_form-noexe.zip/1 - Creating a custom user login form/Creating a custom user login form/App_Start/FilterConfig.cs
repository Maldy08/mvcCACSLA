﻿using System.Web;
using System.Web.Mvc;

namespace Creating_a_custom_user_login_form
{
    public class FilterConfig
    {
        public static void RegisterGlobalFilters(GlobalFilterCollection filters)
        {
            filters.Add(new HandleErrorAttribute());
        }
    }
}